<?php


function fetch_all_junkyard_posts($paged = 1) {
	
	
	 $args = array(
        'post_type' => 'junkyard',  // Your custom post type
        'posts_per_page' => -1,      // Limit the number of posts
		'post__in'       => $junkyards,
               
    );
   
 
    $query = new WP_Query($args);
 
    if ($query->have_posts()) {
  $i=0;
        while ($query->have_posts()) {  $query->the_post();
			$i++;
			
		}
	}
    $args = array(
        'post_type' => 'junkyard',  // Your custom post type
        'posts_per_page' => 5,      // Limit the number of posts
        'paged' => $paged , 
		'post__in'       => $junkyards,           // Current page number
    );
	 
      $start = ($paged * 5) - 4;
	  $end = $start;
    $query = new WP_Query($args);
$html ="";
    if ($query->have_posts()) {
  
			
			 $html  = $html . '<div class="junkyard-item-container">';
			 
			  $html  = $html . '<div class="junkyard-item-row header-row">';
			 $html  = $html . '<div class="junkyard-item">';  
			$html  = $html . '</div>';
			$html  = $html . '<div class="junkyard-item">';
			$html  = $html . '<strong>'.pll__('Name').'</strong>'; 
			$html  = $html . '</div>';
			$html  = $html . '<div class="junkyard-item">';
			$html  = $html . '<strong>'.pll__('Location').'</strong>'; 
			$html  = $html . '</div>'; 
			$html  = $html . '<div class="junkyard-item">';
			$html  = $html . '<strong>'.pll__('Vehicle Available').'</strong>'; 
			$html  = $html . '</div>'; 
			$html  = $html . '<div class="junkyard-item">';
			$html  = $html . '<strong>'.pll__('Spare parts Available').'</strong>'; 
			$html  = $html . '</div>'; 
			$html  = $html . '<div class="junkyard-item junkyard-actions">'; 
			
			$html  = $html . '<strong>'.pll__('Actions').'</strong>'; 
			$html  = $html . '</div>';
			$html  = $html . '</div>';  
		 while ( $query->have_posts() ) : $query->the_post();	
			
		 
	 //get no of vehicles found	  
		$args2 = array(
			'post_type' => array('vehicle'), 
			'posts_per_page' => -1, // Get all posts
			'meta_query' => array(
				array(
					'key'     => '_associated_junkyard',       // The custom field key
					'value'   => get_the_ID(),          // The value to compare 
					'compare' => '=',            // Comparison operator (>, >=, =, !=, etc.)
				),
			),
		);

		 

		$cquery = new WP_Query($args2);
		$v=0;
		if ( $cquery->have_posts() ) :
			while ( $cquery->have_posts() ) : $cquery->the_post();

				$v++;
			endwhile;
			wp_reset_postdata();
		endif;	
		//get no of spare parts found	  
		$args2 = array(
			'post_type' => array( 'spare-part'), 
			'posts_per_page' => -1, // Get all posts
			'meta_query' => array(
				array(
					'key'     => '_associated_junkyard',       // The custom field key
					'value'   => get_the_ID(),          // The value to compare 
					'compare' => '=',            // Comparison operator (>, >=, =, !=, etc.)
				),
			),
		);

	 
		$cquery = new WP_Query($args2);
		$i=0;
		if ( $cquery->have_posts() ) :
			while ( $cquery->have_posts() ) : $cquery->the_post();

				$i++;
			endwhile;
			wp_reset_postdata();
		endif;
			
		 
			 $featuredimage = wp_get_attachment_image_src(get_post_thumbnail_id($currentid), 'full');
            // Output your post content here 
			
			 if(is_null($featuredimage[0])){
				  $junkyard_image = get_stylesheet_directory_uri().'/images/junkyard-placeholder.png';
			 }else{
				 $junkyard_image = $featuredimage[0];
			 }
			 $html  = $html . '<div class="junkyard-item-row desktop">';
			 $html  = $html . '<div class="junkyard-item first-col">'; 
			 	if(get_field('delivery_available',$currentid)=="Yes"){
			 $html  = $html . ' <div class="delivery-label">';
         $html  = $html . 'Delivery Available';
     $html  = $html . '</div>';
				}
			$html  = $html . '<a href="'.get_permalink($currentid).'" class="go-to-junkyard"><img src="'.$junkyard_image.'" alt="Junkyard Logo" class="junkyard-logo"></a>';
			$html  = $html . '</div>';
			$html  = $html . '<div class="junkyard-item">'; 
			
			$html  = $html . '<strong class="mobile-show">'.pll__('Name').'</strong>'; 
			$html  = $html . '<p>'.get_the_title($currentid).'</p>';
			$html  = $html . '</div>';
			$html  = $html . '<div class="junkyard-item">'; 
			$html  = $html . '<strong class="mobile-show">'.pll__('Location').'</strong>'; 
			$html  = $html . '<p>'.get_field('address',$currentid).'</p>';
			$html  = $html . '</div>'; 
			$html  = $html . '<div class="junkyard-item">'; 
			$html  = $html . '<strong class="mobile-show">'.pll__('Vehicle Available').'</strong>'; 
			$html  = $html . '<p>'.$v.'</p>';
			$html  = $html . '</div>';
			$html  = $html . '<div class="junkyard-item">';
			$html  = $html . '<strong class="mobile-show">'.pll__('Spare parts Available').'</strong>';  
			$html  = $html . '<p>'.$i.'</p>';
			$html  = $html . '</div>';
			$html  = $html . '<div class="junkyard-item junkyard-actions">';
			$html  = $html . '<strong><a    href="https://api.whatsapp.com/send?phone='.get_field('whatsapp',$currentid).' &amp;text=I%27d%20have%20an%20enquiry...."><img src="'.get_stylesheet_directory_uri().'/images/icons8-whatsapp-48.png"></a> ';
			$html  = $html . '<a href="tel:'.get_field('phone',$currentid).' "><img src="'.get_stylesheet_directory_uri().'/images/icons8-phone-48.png"></i></a>';
			$html  = $html . '<a href="'.get_field('google_location',$currentid).'" target="_blank"><img src="'.get_stylesheet_directory_uri().'/images/icons8-location-48.png"></a></strong>'; 
			if(get_field('show_more_details',$currentid)=="Yes"){
			$html  = $html . '<p><span class="junkyard-more">';
			$html  = $html . '<a href="'.get_permalink($currentid).'" class="go-to-junkyard">'.pll__('More Details').' <img src="'.get_stylesheet_directory_uri().'/images/right-green-arrow.png"></a>';
			}
			$html  = $html . '</span>';
			$html  = $html . '</p>';
			$html  = $html . '</div>';
			$html  = $html . '</div>'; 
			
			//mobile-show
			
			 $html  = $html . '<div class="junkyard-item-row mobile   d-inline-flex  row">';
			 	$html  = $html . '<div class="junkyard-left-item">'; 
			 $html  = $html . '<div class="junkyard-item first-col">'; 
			 	if(get_field('delivery_available',$currentid)=="Yes"){
			 $html  = $html . ' <div class="delivery-label">';
         $html  = $html . 'Delivery Available';
     $html  = $html . '</div>';
				}
			$html  = $html . '<a href="'.get_permalink($currentid).'" class="go-to-junkyard"><img src="'.$junkyard_image.'" alt="Junkyard Logo" class="junkyard-logo"></a>';
			 
		
			 
			$html  = $html . '<p>'.get_the_title($currentid).'</p>';
			$html  = $html . '</div>';
			$html  = $html . '</div>';
			 $html  = $html . '<div class="junkyard-right-item">'; 
			$html  = $html . '<div class="junkyard-item">'; 
			$html  = $html . '<strong class="mobile-show">'.pll__('Location').'</strong>'; 
			$html  = $html . '<p>'.get_field('address',$currentid).'</p>';
			$html  = $html . '</div>'; 
			$html  = $html . '<div class="junkyard-item">'; 
			$html  = $html . '<strong class="mobile-show">'.pll__('Vehicle Available').'</strong>'; 
			$html  = $html . '<p>'.$v.'</p>';
			$html  = $html . '</div>';
			$html  = $html . '<div class="junkyard-item">';
			$html  = $html . '<strong class="mobile-show">'.pll__('Spare parts Available').'</strong>';  
			$html  = $html . '<p>'.$i.'</p>';
			$html  = $html . '</div>';
			$html  = $html . '<div class="junkyard-item junkyard-actions">';
			$html  = $html . '<strong><a    href="https://api.whatsapp.com/send?phone='.get_field('whatsapp',$currentid).' &amp;text=I%27d%20have%20an%20enquiry...."><img src="'.get_stylesheet_directory_uri().'/images/icons8-whatsapp-48.png"></a> ';
			$html  = $html . '<a href="tel:'.get_field('phone',$currentid).' "><img src="'.get_stylesheet_directory_uri().'/images/icons8-phone-48.png"></i></a>';
			$html  = $html . '<a href="'.get_field('google_location',$currentid).'" target="_blank"><img src="'.get_stylesheet_directory_uri().'/images/icons8-location-48.png"></a></strong>'; 
			if(get_field('show_more_details',$currentid)=="Yes"){
			$html  = $html . '<p><span class="junkyard-more">';
			$html  = $html . '<a href="'.get_permalink($currentid).'" class="go-to-junkyard">'.pll__('More Details').' <img src="'.get_stylesheet_directory_uri().'/images/right-green-arrow.png"></a>';
			}
			$html  = $html . '</span>';
			$html  = $html . '</p>';
			$html  = $html . '</div>';
			$html  = $html . '</div>'; 
			$html  = $html . '</div>'; 
          $end++;
        endwhile;
$end--;
        // Pagination
        $total_pages = $query->max_num_pages;
		     $html  = $html . '</div>';
		
        if ($total_pages > 1) {
            $html  = $html . '<div class="pagination" total_pages="'.$total_pages.'"   totalcount="'.$i.'"    start-row ="'.$start.'"  end-row ="'.$end.'" >';
            for ($i = 1; $i <= $total_pages; $i++) {
				$active = "";
				if($paged==$i){
					$active = "active";
				}
                $html  = $html . '<span class="junk-page-numbers '.$active.'" data-page="' . $i . '"  >' . $i . '</span>';
            }
            $html  = $html . '</div>';
        }

        wp_reset_postdata();  // Restore original post data
		 
        return $html; // Return the buffered content
		
    } else {
        return pll__('No junkyard posts found').'.';
    }
}



function load_all_junkyard_posts() {
    $paged = isset($_POST['page']) ? intval($_POST['page']) : 1; // Get the page number from the AJAX request 
		 
	$junkyards = explode(",",$junkyards);
 
     $html = fetch_all_junkyard_posts($paged);
	$result = 1;
    echo json_encode(array(
        'html' => $html,
        'paging' => $paged 
    ));
    wp_die();  // Required to terminate immediately and return a proper response
}
add_action('wp_ajax_load_all_junkyard_posts', 'load_all_junkyard_posts');
add_action('wp_ajax_nopriv_load_all_junkyard_posts', 'load_all_junkyard_posts'); // For non-logged in users





