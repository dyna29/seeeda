<?php

function remove_wp_dashboard_widgets() {
    global $wp_meta_boxes;
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_activity']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
}
add_action('wp_dashboard_setup', 'remove_wp_dashboard_widgets');


function custom_dashboard_menu() {
    add_menu_page(
        'Custom Dashboard',  // Page title
        'Dashboard',          // Menu title
        'edit_vehicle',     // Capability
        'custom-dashboard',   // Menu slug
        'custom_dashboard_content', // Callback function
        'dashicons-dashboard', // Icon
        2                     // Position
    );
}
add_action('admin_menu', 'custom_dashboard_menu');

function custom_dashboard_content() {
    echo '<h1>Welcome to your Custom Dashboard!</h1>';
    echo '<p>This is a fully custom dashboard tailored for your needs.</p>';
}
function remove_default_dashboard_menu_item() {
    
        remove_menu_page('index.php'); // Removes the default dashboard menu for non-admins
     
}
add_action('admin_menu', 'remove_default_dashboard_menu_item');
add_action('wp_login', 'custom_role_based_login_redirect', 10, 2);
function custom_role_based_login_redirect($user_login, $user) {
    // Check if the user has the role 'junkyards_administrator' or 'junkyard_manager'
    if (in_array('junkyards_administrator', (array) $user->roles) || in_array('junkyard_manager', (array) $user->roles)) {
        // Set the redirect URL to the user portal page
		 update_user_meta($user->ID, 'last_login', current_time('mysql'));
        $redirect_url = home_url('/user-dashboard/');
        
        // Redirect the user
        wp_redirect($redirect_url);
        exit;
    }
}

