<?php
 
function custom_post_init()
{
  
    $labels = array(
        'name' => _x('Junkyard', 'post type general name', 'cdr'),
        'singular_name' => _x('Junkyard', 'post type singular name', 'cdr'),
        'menu_name' => _x('Junkyards', 'admin menu', 'cdr'),
        'name_admin_bar' => _x('Junkyard', 'add new on admin bar', 'cdr'),
        'add_new' => _x('Add New Junkyard', 'hotel', 'cdr'),
        'add_new_item' => __('Add New Junkyard', 'cdr'),
        'new_item' => __('New Junkyard', 'cdr'),
        'edit_item' => __('Edit Junkyard', 'cdr'),
        'view_item' => __('View Junkyard', 'cdr'),
        'all_items' => __('All Junkyards', 'cdr'),
        'search_items' => __('Search Junkyards', 'cdr'),
        'parent_item_colon' => __('Parent Junkyards:', 'cdr'),
        'not_found' => __('No Junkyards found.', 'cdr'),
        'not_found_in_trash' => __('No Junkyards found in Trash.', 'cdr')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cdr'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'junkyard'
        ),
        'capability_type' => 'junkyard',
		  'capabilities' => array(
            'edit_post' => 'edit_junkyard',
            'edit_posts' => 'edit_junkyards',
            'edit_others_posts' => 'edit_others_junkyards',
            'publish_posts' => 'publish_junkyards',
            'read_post' => 'read_junkyard',
            'read_private_posts' => 'read_private_junkyards',
            'delete_post' => 'delete_junkyard',
        ),
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'thumbnail',
            'excerpt', 'page-attributes',
        )
    );
    register_post_type('junkyard', $args);
	
	  $labels = array(
        'name' => _x('Vehicle', 'post type general name', 'cdr'),
        'singular_name' => _x('Vehicle', 'post type singular name', 'cdr'),
        'menu_name' => _x('Vehicles', 'admin menu', 'cdr'),
        'name_admin_bar' => _x('Vehicle', 'add new on admin bar', 'cdr'),
        'add_new' => _x('Add New Vehicle', 'hotel', 'cdr'),
        'add_new_item' => __('Add New Vehicle', 'cdr'),
        'new_item' => __('New Vehicle', 'cdr'),
        'edit_item' => __('Edit Vehicle', 'cdr'),
        'view_item' => __('View Vehicle', 'cdr'),
        'all_items' => __('All Vehicles', 'cdr'),
        'search_items' => __('Search Vehicles', 'cdr'),
        'parent_item_colon' => __('Parent Vehicles:', 'cdr'),
        'not_found' => __('No Vehicles found.', 'cdr'),
        'not_found_in_trash' => __('No Vehicles found in Trash.', 'cdr')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cdr'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'vehicle'
        ),
      
        'capability_type' => 'vehicle',
		  'capabilities' => array(
            'edit_post' => 'edit_vehicle',
            'edit_posts' => 'edit_vehicles',
            'edit_others_posts' => 'edit_others_vehicles',
            'publish_posts' => 'publish_vehicles',
            'read_post' => 'read_vehicle',
            'read_private_posts' => 'read_private_vehicles',
            'delete_post' => 'delete_vehicle',
        ),
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'thumbnail',
            'excerpt', 'page-attributes',
        )
    );
    register_post_type('vehicle', $args);
	   $labels = array(
        'name' => _x('Spare Part', 'post type general name', 'cdr'),
        'singular_name' => _x('Spare Part', 'post type singular name', 'cdr'),
        'menu_name' => _x('Spare Parts', 'admin menu', 'cdr'),
        'name_admin_bar' => _x('Spare Part', 'add new on admin bar', 'cdr'),
        'add_new' => _x('Add New Spare Part', 'hotel', 'cdr'),
        'add_new_item' => __('Add New Spare Part', 'cdr'),
        'new_item' => __('New Spare Part', 'cdr'),
        'edit_item' => __('Edit Spare Part', 'cdr'),
        'view_item' => __('View Spare Part', 'cdr'),
        'all_items' => __('All Spare Parts', 'cdr'),
        'search_items' => __('Search Spare Parts', 'cdr'),
        'parent_item_colon' => __('Parent Spare Parts:', 'cdr'),
        'not_found' => __('No Spare Parts found.', 'cdr'),
        'not_found_in_trash' => __('No Spare Parts found in Trash.', 'cdr')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cdr'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'spare-part'
        ),
      
        'capability_type' => 'spare_part',
		  'capabilities' => array(
            'edit_post' => 'edit_spare_part',
            'edit_posts' => 'edit_spare_parts',
            'edit_others_posts' => 'edit_others_spare_parts',
            'publish_posts' => 'publish_spare_parts',
            'read_post' => 'read_spare_part',
            'read_private_posts' => 'read_private_spare_parts',
            'delete_post' => 'delete_spare_part',
        ),
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'thumbnail',
            'excerpt', 'page-attributes',
        )
    );
    register_post_type('spare-part', $args); 	   
}
add_action('init', 'custom_post_init');


function custom_taxonomy_init()
{
    
        $labels = array(
        'name' => _x('Brand', 'taxonomy general name'),
        'singular_name' => _x('Brand', 'taxonomy singular name'),
        'search_items' => __('Search Brand'),
        'all_items' => __('All Brand'),
        'parent_item' => __('Parent Brand'),
        'parent_item_colon' => __('Parent Brand:'),
        'edit_item' => __('Edit Brand'),
        'update_item' => __('Update Brand'),
        'add_new_item' => __('Add New Brand'),
        'new_item_name' => __('New Brand'),
        'menu_name' => __('Brand')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'brand'
        ),
		 'capabilities'      => array(
            'manage_terms' => 'manage_brand',  // Custom capability to manage the brand taxonomy
            'edit_terms'   => 'edit_brand',    // Custom capability to edit terms in brand
            'delete_terms' => 'delete_brand',  // Custom capability to delete terms in brand
            'assign_terms' => 'assign_brand',  // Custom capability to assign brand terms to posts
        ),
    );
    register_taxonomy('brand', array(
        'vehicle','spare-part'
    ), $args);
	    $labels = array(
        'name' => _x('Engine Type', 'taxonomy general name'),
        'singular_name' => _x('Engine Type', 'taxonomy singular name'),
        'search_items' => __('Search Engine Type'),
        'all_items' => __('All Engine Type'),
        'parent_item' => __('Parent Engine Type'),
        'parent_item_colon' => __('Parent Engine Type:'),
        'edit_item' => __('Edit Engine Type'),
        'update_item' => __('Update Engine Type'),
        'add_new_item' => __('Add New Engine Type'),
        'new_item_name' => __('New Engine Type'),
        'menu_name' => __('Engine Type')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'engine-type'
        ), 
    );
    register_taxonomy('engine-type', array(
        'vehicle','spare-part'
    ), $args);
         $labels = array(
        'name' => _x('Model Year', 'taxonomy general name'),
        'singular_name' => _x('Model Year', 'taxonomy singular name'),
        'search_items' => __('Search Model Year'),
        'all_items' => __('All Model Year'),
        'parent_item' => __('Parent Model Year'),
        'parent_item_colon' => __('Parent Model Year:'),
        'edit_item' => __('Edit Model Year'),
        'update_item' => __('Update Model Year'),
        'add_new_item' => __('Add New Model Year'),
        'new_item_name' => __('New Model Year'),
        'menu_name' => __('Model Year')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'model-year'
        ),
		 'capabilities'      => array(
            'manage_terms' => 'manage_model-year',  // Custom capability to manage the brand taxonomy
            'edit_terms'   => 'edit_model-year',    // Custom capability to edit terms in brand
            'delete_terms' => 'delete_model-year',  // Custom capability to delete terms in brand
            'assign_terms' => 'assign_model-year',  // Custom capability to assign brand terms to posts
        ),
    );
    register_taxonomy('model-year', array(
        'vehicle','spare-part'
    ), $args);
   
       $labels = array(
        'name' => _x('Spare Part Type', 'taxonomy general name'),
        'singular_name' => _x('Spare Part Type', 'taxonomy singular name'),
        'search_items' => __('Search Spare Part Type'),
        'all_items' => __('All Spare Part Type'),
        'parent_item' => __('Parent Spare Part Type'),
        'parent_item_colon' => __('Parent Spare Part Type:'),
        'edit_item' => __('Edit Spare Part Type'),
        'update_item' => __('Update Spare Part Type'),
        'add_new_item' => __('Add New Spare Part Type'),
        'new_item_name' => __('New Spare Part Type'),
        'menu_name' => __('Spare Part Type')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'spare-part-type'
        )
    );
    register_taxonomy('spare-part-type', array(
        'spare-part','vehicle'
    ), $args);   
	
	
           $labels = array(
        'name' => _x('Wheel Size', 'taxonomy general name'),
        'singular_name' => _x('Wheel Size', 'taxonomy singular name'),
        'search_items' => __('Search Wheel Size'),
        'all_items' => __('All Wheel Size'),
        'parent_item' => __('Parent Wheel Size'),
        'parent_item_colon' => __('Parent Wheel Size:'),
        'edit_item' => __('Edit Wheel Size'),
        'update_item' => __('Update Wheel Size'),
        'add_new_item' => __('Add New Wheel Size'),
        'new_item_name' => __('New Wheel Size'),
        'menu_name' => __('Wheel Size')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'wheel-size'
        )
    );
    register_taxonomy('wheel-size', array(
        'spare-part','vehicle'
    ), $args);    
	
	
       $labels = array(
        'name' => _x('Wheel Material', 'taxonomy general name'),
        'singular_name' => _x('Wheel Material', 'taxonomy singular name'),
        'search_items' => __('Search Wheel Material'),
        'all_items' => __('All Wheel Material'),
        'parent_item' => __('Parent Wheel Material'),
        'parent_item_colon' => __('Parent Wheel Material:'),
        'edit_item' => __('Edit Wheel Material'),
        'update_item' => __('Update Wheel Material'),
        'add_new_item' => __('Add New Wheel Material'),
        'new_item_name' => __('New Wheel Material'),
        'menu_name' => __('Wheel Material')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'wheel-material','vehicle'
        )
    );
    register_taxonomy('wheel-material', array(
        'spare-part'
    ), $args);  

 $labels = array(
        'name' => _x('Wheel Lug Nut', 'taxonomy general name'),
        'singular_name' => _x('Wheel Lug Nut', 'taxonomy singular name'),
        'search_items' => __('Search Wheel Lug Nut'),
        'all_items' => __('All Wheel Lug Nut'),
        'parent_item' => __('Parent Wheel Lug Nut'),
        'parent_item_colon' => __('Parent Wheel Lug Nut:'),
        'edit_item' => __('Edit Wheel Lug Nut'),
        'update_item' => __('Update Wheel Lug Nut'),
        'add_new_item' => __('Add New Wheel Lug Nut'),
        'new_item_name' => __('New Wheel Lug Nut'),
        'menu_name' => __('Wheel Lug Nut')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'wheel-lug-nut'
        )
    );
    register_taxonomy('wheel-lug-nut', array(
        'spare-part','vehicle'
    ), $args); 	
}
add_action('init', 'custom_taxonomy_init');