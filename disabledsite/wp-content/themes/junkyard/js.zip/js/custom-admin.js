// custom-admin.js
jQuery(document).ready(function($) {
   wrapwidth =  jQuery('.wrap').width()-60
   
   jQuery('.wrap h1').width(wrapwidth)
});

 jQuery(document).ready(function($) {
	 
 
    // Get the spare part type checkboxes and wheel width section
    var sparePartTypeCheckboxes = $('input[name="tax_input[spare-part-type][]"]');  // Spare part type checkboxes
    var wheelWidthBox = $('#wheel-widthdiv'); // Taxonomy metabox for wheel width
    var wheelMaterialBox = $('#wheel-materialdiv'); // Taxonomy metabox for wheel width

    // Function to toggle wheel width based on the selection of the 'Wheel' checkbox
    function toggleWheelWidth() {
        var isWheelSelected = $('input[name="tax_input[spare-part-type][]"][value="332"]').is(':checked');  // Replace 'wheel' with actual term ID or slug if different
        if (isWheelSelected) {
            wheelWidthBox.show();
            wheelMaterialBox.show();
        } else {
            wheelWidthBox.hide();
            wheelMaterialBox.hide();
        }
    }

    // Initial check when the page loads
    toggleWheelWidth();

    // Check again when the spare part type checkboxes are changed
    sparePartTypeCheckboxes.click(function() {
	 
        toggleWheelWidth();
    });
});
