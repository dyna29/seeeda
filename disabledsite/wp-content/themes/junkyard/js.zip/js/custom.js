// custom-admin.js

jQuery(document).ready(function($) {
    // Initialize Select2 on the brand dropdown
	
		if($('#spare_part-dropdown2').length){
				$('#spare_part-dropdown2').select2({
				placeholder: globalvar.show_all,
				allowClear: true, // Adds the 'X' clear button     
            
				width: '100%', // Ensures the dropdown uses full width of the container
				 dropdownParent: $('#searchModal') 
			});
		}
		if($('#model_year-dropdown2').length){
			$('#model_year-dropdown2').select2({
			placeholder: globalvar.show_all,
			allowClear: true,  
			width: '100%',  // Ensures the dropdown uses full width of the container, // Adds the 'X' clear button
				 dropdownParent: $('#searchModal') // Ensure dropdown stays inside the modal
		});
		}
		if($('#brand-dropdown2').length){
 
					$('#brand-dropdown2').select2({
					placeholder: globalvar.show_all, // Placeholder text
					allowClear: true, // Adds the 'X' clear button     
                  
					dropdownParent: $('#searchModal') // Ensure dropdown stays inside the modal
				});
				
        getmodels2()
		}
		if($('#model-dropdown2').length){
 
				$('#model-dropdown2').select2({
				placeholder: globalvar.show_all, // Placeholder text
				allowClear: true, // Adds the 'X' clear button     
               
				 dropdownParent: $('#searchModal') // Ensure dropdown stays inside the modal
			});
		}
    if (jQuery('#brand-dropdown').length) {
		
	
		if($("#searchModal").length){
				$('#brand-dropdown').select2({
					placeholder: globalvar.show_all, // Placeholder text
					allowClear: true,   // Adds the 'X' clear button     
                   
				});
				
		}else{
			
				$('#brand-dropdown').select2({
					placeholder: globalvar.show_all, // Placeholder text
					allowClear: true, // Adds the 'X' clear button     
                  
				});
		}
		if($("#searchModal").length){
			$('#model-dropdown').select2({
				placeholder: globalvar.show_all, // Placeholder text
				allowClear: true, // Adds the 'X' clear button     
                
			});
		}else{
			$('#model-dropdown').select2({
				placeholder: globalvar.show_all, // Placeholder text
				allowClear: true , // Adds the 'X' clear button     
              
			});
		}
        getmodels()
        $("#total-row-start").html($(".pagination").attr('start-row'))
        $("#total-row-end").html($(".pagination").attr('end-row'))
        $("#total-pages").html($(".pagination").attr('totalcount'))

    }
	if($("#searchModal").length){
		$('#model_year-dropdown').select2({
			placeholder: globalvar.show_all,
			allowClear: true, 
			width: '100%',  // Ensures the dropdown uses full width of the container, // Adds the 'X' clear button
				 
		});
	}else{
		
		$('#model_year-dropdown').select2({
			placeholder: globalvar.show_all,
			allowClear: true,  
			width: '100%' // Ensures the dropdown uses full width of the container
		});
	}
		if($("#searchModal").length){
			$('#spare_part-dropdown').select2({
				placeholder: globalvar.show_all,
				allowClear: true, // Adds the 'X' clear button     
              
				width: '100%', // Ensures the dropdown uses full width of the container
				 
			});
		}else{
			$('#spare_part-dropdown').select2({
				placeholder: globalvar.show_all,
				allowClear: true, // Adds the 'X' clear button     
               
				width: '100%' // Ensures the dropdown uses full width of the container
			});
		}

    $('#brand-dropdown2').on('change', function() {

        getmodels2()
    })
    $('#brand-dropdown').on('change', function() {

        getmodels()
    })

 $('.child-spare').on('click', function() {
	 
	 spareparent=$(this).attr('parent')
	 $parent = $('#sp' + spareparent);  
	  if ($('.sp-'+spareparent+'.child-spare:checked').length > 0) {
            // If checked, check the parent
            $parent.prop('checked', true);
        } else {
            // If unchecked, uncheck the parent
            $parent.prop('checked', false);
        }
	 
 })
    $('.checkall').on('click', function() {
		  sp=$(this).attr('sp')
		  
	jQuery(".sp-"+sp).prop('checked', true);
	})
    $('.uncheckall').on('click', function() {
		  sp=$(this).attr('sp')
	jQuery(".sp-"+sp).prop('checked', false);
	})
    $('.show-filter').on('click', function() {
		  
		jQuery('.sidebar-filter').addClass('active')
	})
    $('.search-close').on('click', function() {
		  
		jQuery('.sidebar-filter').removeClass('active')
	})
	
	 
    $('.show-more-vinfo').on('click', function() {
		ind = jQuery(this).attr('ind')
		jQuery(".vehicle-info-"+ind).toggleClass('active')
		jQuery(this).toggleClass('active')
	})
    $('.wheel-filter').on('click', function() {
		
		if($('.sidebar-filter').hasClass('active')){
			$('.sidebar-filter').removeClass('active')
		}
		filter = $(this).attr("filter")
		 $(this).addClass('active')
            item = $(this).attr("item")
			// Get the current selection
    var currentSelection = $('#spare_part-dropdown').val() || [];

    // Add the new item to the array (ensure it's not already present)
 console.log(currentSelection)
 
		 
		 	if (!currentSelection.includes(item)) {
        currentSelection.push(item);
    }  
	 
     console.log(currentSelection)
            $('#spare_part-dropdown').val(currentSelection).trigger('change');;
        
		$('#wheel-filter').addClass('active')
	})
    $('#close-wheel-filter').on('click', function() {
		$('#wheel-filter').removeClass('active')
		$('.wheel-filter').removeClass('active')
		    var currentSelection = $('#spare_part-dropdown').val() || [];
			 $('.wheel-filter').attr("item")
			if (currentSelection.includes(item)) {
				currentSelection.pop(item);
			}
			 $('#spare_part-dropdown').val(currentSelection).trigger('change');;
	})
    $('.go-to-junkyard').on('click', function() {
        $(".search-form").attr("action", $(this).attr('junkyard'))
        $(".search-form").submit()

    })
	
	$(".brand-filter-item").on('click', function() {
		
		brand = $(this).attr("item")
	  $('html, body').animate({
            scrollTop: $('.search-section-container').offset().top
        }, 800); // Adjust the speed in milliseconds (800ms here)
    
		//$("#model-dropdown").val("").trigger('change');
		//$("#model_year-dropdown").val("").trigger('change');
		//$("#spare_part-dropdown").val("").trigger('change');
		     $('#brand-dropdown').val(brand).trigger('change');
		$("#brand-dropdown").val(brand)
		 jQuery("#search-now").trigger('click')
		// jQuery(".search-form").submit()
	})
    $('#search-now').on('click', function() {
		submitform = 1 
		$('.error').remove()
		if($("#brand-dropdown").val()=="" ||  $("#brand-dropdown").val()==null){
			submitform = 0
			$("#brand-dropdown").parent().append("<span class='error'>Please select brand</span>")
		}
		if($("#model-dropdown").val()=="" ||  $("#model-dropdown").val()==null){
			submitform = 0
			$("#model-dropdown").parent().append("<span class='error'>Please select model</span>")
		} 
		 
         if(submitform == 1){
			jQuery(".filtering").addClass("active")
			$(".search-form").submit()
		}else{
			jQuery(".filtering").removeClass("active")
		}
    })
    $('#search-now-2').on('click', function() {
		submitform = 1 
		$('.error').remove()
		if($("#brand-dropdown2").val()=="" ||  $("#brand-dropdown2").val()==null){
			submitform = 0
			$("#brand-dropdown2").parent().append("<span class='error'>Please select brand</span>")
		}
		if($("#model-dropdown2").val()=="" ||  $("#model-dropdown2").val()==null){
			submitform = 0
			$("#model-dropdown2").parent().append("<span class='error'>Please select model</span>")
		} 
		 
         if(submitform == 1){
			jQuery(".filtering").addClass("active")
		 	$(".search-form-2").submit()
		}else{
			jQuery(".filtering").removeClass("active")
		}
    })
    $('#showmorebrands').on('click', function() {
		$(".hiddenbranditem").toggleClass('active')
})
    $('#showmoreyears').on('click', function() {
		$(".hiddencategoryitem").toggleClass('active')
})
    $('#filterwheels').on('click', function() {
		jQuery(".filtering").addClass("active")
		let selectedwheel_sizeValues = $(".wheel_size:checked")
			.map(function() {
				return $(this).val();
			})
			.get()
			.join(","); 
		jQuery("#wheel-size").val(selectedwheel_sizeValues)
		
		let selectedwheel_lugnutValues = $(".wheel_lugnut:checked")
			.map(function() {
				return $(this).val();
			})
			.get()
			.join(","); 
		jQuery("#wheel-lug-nut").val(selectedwheel_lugnutValues)
		let selectedwheel_typeValues = $(".wheel_type:checked")
			.map(function() {
				return $(this).val();
			})
			.get()
			.join(","); 
		jQuery("#wheel-type").val(selectedwheel_typeValues)
		        jQuery("#search-now").trigger('click')
	})
    $('.filter-item-pop').on('click', function() {
		item = $(this).attr("item")
		 $('#brand-dropdown2').val(item).trigger('change');
	})
	
	 
    $('.filter-item').on('click', function() {
		
        filter = $(this).attr("filter")
jQuery(".filtering").addClass("active")
        if (filter == "brand") {
            item = $(this).attr("item")
            $('#brand-dropdown').val(item).trigger('change');
        }
        if (filter == "model-year") {
            item = $(this).attr("item")
            $('#model_year-dropdown').val(item).trigger('change');
        }
        if (filter == "spare-part-type") {
            item = $(this).attr("item")
			// Get the current selection
    var currentSelection = $('#spare_part-dropdown').val() || [];

    // Add the new item to the array (ensure it's not already present)
 
 if( $(this).hasClass('active')){
		 
		if (currentSelection.includes(item)) {
        currentSelection.pop(item);
    } 
	 }else{
		
		if (!currentSelection.includes(item)) {
        currentSelection.push(item);
    }  
	 }
    
            $('#spare_part-dropdown').val(currentSelection).trigger('change');
        }
        if (filter == "wheel-size") {
            item = $(this).attr("item")
            $('#wheel-size').val(item) ;
        }
        jQuery("#search-now").trigger('click')
		
        
    })



    $('body').on('click', '.phone-call', function() {
		junkyard = $(this).attr('junkyard')
		
		 $.ajax({
            type: 'POST',
            url: globalvar.ajax_url,
            data: {
                action: 'phone_junkyard', // AJAX action  
				junkyard:junkyard,
            },
            success: function(response) {
                // Replace the junkyard posts with the new content
                response = jQuery.parseJSON(response)
                
            }
        });
	})

    $('body').on('click', '.whatsapp-call', function() {
		junkyard = $(this).attr('junkyard')
		
		 $.ajax({
            type: 'POST',
            url: globalvar.ajax_url,
            data: {
                action: 'whatsapp_junkyard', // AJAX action 
				junkyard:junkyard, 
            },
            success: function(response) {
                // Replace the junkyard posts with the new content
                response = jQuery.parseJSON(response)
                
            }
        });
	})
    $('body').on('click', '.junk-page-numbers', function() {

        jQuery(".filtering").addClass("active")
        var page = $(this).data('page'); // Get the page number from the clicked element

        $.ajax({
            type: 'POST',
            url: globalvar.ajax_url,
            data: {
                action: 'load_all_junkyard_posts', // AJAX action 
                page: page, // Pass the page number 
            },
            success: function(response) {
                // Replace the junkyard posts with the new content
                response = jQuery.parseJSON(response)
                $('.junkyard-list').html(response.html);
                $("#total-row-start").html($(".pagination").attr('start-row'))
                $("#total-row-end").html($(".pagination").attr('end-row'))
                $("#total-pages").html($(".pagination").attr('totalcount'))
                jQuery(".filtering").removeClass("active")
            }
        });
    });
    $('body').on('click', '.vs-page-numbers ', function() {

        jQuery(".filtering").addClass("active")
        var page = $(this).data('page'); // Get the page number from the clicked element

        $.ajax({
            type: 'POST',
            url: globalvar.ajax_url,
            data: {
                action: 'load_vehicle_spare_posts', // AJAX action
                brand: $('#brand-dropdown').val(), // Pass the page number 
                model: $('#model-dropdown').val(), // Pass the page number 
                model_year: $('#model_year-dropdown').val(), // Pass the page number 
                spare_category: $('#spare_part-dropdown').val(), // Pass the page number 
                junkyard: $('#junkyard').val(), // Pass the page number 
                page: page, // Pass the page number 
            },
            success: function(response) {
                // Replace the junkyard posts with the new content
                response = jQuery.parseJSON(response)
                $('.vehicle-spare-list').html(response.html);
                $("#total-row-start").html($(".pagination").attr('start-row'))
                $("#total-row-end").html($(".pagination").attr('end-row'))
                $("#total-pages").html($(".pagination").attr('totalcount'))
                jQuery(".filtering").removeClass("active")
            }
        });
    });
    $('body').on('click', '.page-numbers', function() {

        jQuery(".filtering").addClass("active")
        var page = $(this).data('page'); // Get the page number from the clicked element
        sjunkyards = $("#sjunkyards").val()
        $.ajax({
            type: 'POST',
            url: globalvar.ajax_url,
            data: {
                action: 'load_junkyard_posts', // AJAX action
                page: page, // Pass the page number
                junkyards: sjunkyards // Pass the page number
            },
            success: function(response) {
                // Replace the junkyard posts with the new content
                response = jQuery.parseJSON(response)
                $('.junkyard-list').html(response.html);
                $("#total-row-start").html($(".pagination").attr('start-row'))
                $("#total-row-end").html($(".pagination").attr('end-row'))
                $("#total-pages").html($(".pagination").attr('totalcount'))
                jQuery(".filtering").removeClass("active")
            }
        });
    });
});

// AJAX call when brand is selected
function getmodels2() {

    var brandID = $('#brand-dropdown2').val(); // Get selected brand ID
//jQuery(".dd-model2 span.select2-selection__placeholder").html("Fetching Data...")
modeldata = jQuery(".model-data2").attr("data")
modeldata = modeldata.split(","); 
 html = "";

modeldata.forEach(function(modeldataitem) {
  
	modeldataitem = modeldataitem.split("=>");
	//console.log("item"+modeldataitem[0]);
	 console.log("brandID"+brandID);
	
if(modeldataitem[0]==brandID){ 
	 html += "<option value='"+modeldataitem[2]+"'>"+modeldataitem[1]+"</option>";
}	
	  
});   

   if (brandID) {
	   
	    $('#model-dropdown2').html(html).trigger('change');
		
		
				  var selectBox =$('#model-dropdown2'); // Target select box

    var options = selectBox.find("option").toArray(); // Convert options to an array

    options.sort(function (a, b) {
		  if (a.text === "Other Models") return 1;  // Move "Other Models" to the end
        if (b.text === "Other Models") return -1;
        return a.text.localeCompare(b.text); // Sort alphabetically
    });

    selectBox.empty().append(options); // Clear and append sorted options
               if ($('#brand-dropdown2').val() == $("#sbrand").val()) {
             
                    $('#model-dropdown2').val($("#smodel").val()).trigger('change');
                 }else{

                    $('#model-dropdown2').val(0).trigger('change');
                 }
	   /* disable ajax
        $.ajax({
            url: globalvar.ajax_url,
            type: 'POST',
            data: {
                action: 'get_models_by_brand',
                brand_id: brandID
            },
            success: function(response) {

                // Populate the models dropdown with the received data
                $('#model-dropdown2').html(response).trigger('change');
                if ($('#brand-dropdown').val() == $("#sbrand").val()) {
             
                    $('#model-dropdown2').val($("#smodel").val()).trigger('change');
                 }else{

                    $('#model-dropdown2').val(0).trigger('change');
                 }

            }
        });*/
    } else {
        // Reset model dropdown if no brand is selected
        $('#model-dropdown').html('<option value="">Select Model</option>');
    }
	
	
};
// AJAX call when brand is selected
function getmodels() {
 
    var brandID = $('#brand-dropdown').val(); // Get selected brand ID
modeldata = jQuery(".model-data").attr("data")
modeldata = modeldata.split(","); 
 html = "";

modeldata.forEach(function(modeldataitem) {
  
	modeldataitem = modeldataitem.split("=>");
	//console.log("item"+modeldataitem[0]);
	 console.log("brandID"+brandID);
	
if(modeldataitem[0]==brandID){ 
	 html += "<option value='"+modeldataitem[2]+"'>"+modeldataitem[1]+"</option>";
}	
	  
});
 
 //jQuery(".dd-model span.select2-selection__placeholder").html("Fetching Data...")
    if (brandID) {
		
		
		
		  $('#model-dropdown').html(html).trigger('change');
		  
		  var selectBox =$('#model-dropdown'); // Target select box

    var options = selectBox.find("option").toArray(); // Convert options to an array

    options.sort(function (a, b) {
		  if (a.text === "Other Models") return 1;  // Move "Other Models" to the end
        if (b.text === "Other Models") return -1;
        return a.text.localeCompare(b.text); // Sort alphabetically
    });

    selectBox.empty().append(options); // Clear and append sorted options
               if ($('#brand-dropdown').val() == $("#sbrand").val()) {
             
                    $('#model-dropdown').val($("#smodel").val()).trigger('change');
                 }else{

                    $('#model-dropdown').val(0).trigger('change');
                 }
       /*disable ajax $.ajax({
            url: globalvar.ajax_url,
            type: 'POST',
            data: {
                action: 'get_models_by_brand',
                brand_id: brandID
            },
            success: function(response) {

                // Populate the models dropdown with the received data
                $('#model-dropdown').html(response).trigger('change');
               if ($('#brand-dropdown').val() == $("#sbrand").val()) {
             
                    $('#model-dropdown').val($("#smodel").val()).trigger('change');
                 }else{

                    $('#model-dropdown').val(0).trigger('change');
                 }


            }
        });*/
    } else {
        // Reset model dropdown if no brand is selected
        $('#model-dropdown').html('<option value="">Select Model</option>');
    }
};

jQuery(document).ready(function($) {
    // Get the spare part type checkboxes and wheel width section
    var sparePartTypeCheckboxes = $('input[name="tax_input[spare-part-type][]"]'); // Spare part type checkboxes
    var wheelWidthBox = $('#wheel-widthdiv'); // Taxonomy metabox for wheel width

    // Function to toggle wheel width based on the selection of the 'Wheel' checkbox
    function toggleWheelWidth() {
        var isWheelSelected = $('input[name="tax_input[spare-part-type][]"][value="332"]').is(':checked'); // Replace 'wheel' with actual term ID or slug if different
        if (isWheelSelected) {
            wheelWidthBox.show();
        } else {
            wheelWidthBox.hide();
        }
    }

    // Initial check when the page loads
    toggleWheelWidth();

    // Check again when the spare part type checkboxes are changed
    sparePartTypeCheckboxes.click(function() {
       
        toggleWheelWidth();
    });
});