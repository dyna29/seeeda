//MOUSE OUT CLIKC MENU CLOSE
$(document).mouseup(function(e) 
{
    var container = $(".drawer-list");
    var container2 = $(".hamburger");
    // IF THE TARGET OF THE CLICK ISN'T THE CONTAINER NOR A DESCENDANT OF THE CONTAINER
    if (!container.is(e.target) && container.has(e.target).length === 0 && !container2.is(e.target) && container2.has(e.target).length === 0) 
    {
		if(jQuery('#hamburger:checked').length==1){
			jQuery('label.hamburger').trigger('click')
		} 
    }
})

//EMAIL VALIDATION FUNCTION
function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};

//LIMIT TEXT FUNCTION
function charLimit(input, maxChar) {
    var len = $(input).val();
    if (parseInt(len) > parseInt(maxChar)) {
        $(input).val(maxChar);
    }
}
//menubar

$('.menu-item-has-children').click(function() {
	$(this).toggleClass('active')
	dwidth = parseFloat($('.drawer-list').width())+60
	console.log(dwidth)
	 $('ul.sub-menu').width(dwidth+'px')

}
)
//HOME PAGE SLIDER
$('#home-slider').owlCarousel({
    items: 1,
    loop: true,
    margin: 0,
    autoplay: true,
    autoplayTimeout: 5000,
    autoplayHoverPause: false,
    transitionStyle: "fade",
    animateOut: 'fadeOut',
    animateIn: 'fadeIn',
    nav: true,
    rtl: true,
    dots: false,
    navText: ["<img src='" + globalvar.assets + "/images/arrow-left.png'>", "<img src='" + globalvar.assets + "/images/arrow-right.png'>"]
}) 

//GL0BAL VAR
var propertyoffset = 0
var filtered = 0

$(document).ready(function() {
	
	//START ANIMATIONS
	AOS.init();
	
	//GO TO TOP ARROW
	$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
	});
	$('#return-to-top').click(function() {      // When arrow is clicked
 
		$('body,html').animate({
			scrollTop : 0                       // Scroll to top of body
		}, 500);
	});
	
	
	//****************************************************COMMON JS STARTS******************************************************//

	jQuery('select#property-contract').select2()
	//****************************************************COMMON JS ENDS******************************************************//
	//****************************************************CUSTOMER JS STARTS******************************************************//

	 
	//customer login
		
	$(".customer_type").click(function() {
		
		if(jQuery(this).val()=='Company'){
			jQuery('.company-label').show()
			jQuery('.individual-label').hide()
		}
		if(jQuery(this).val()=='Individual'){
			jQuery('.company-label').hide()
			jQuery('.individual-label').show()
		}
	})
	$("#customer-login").click(function() {
		error = 0
		$('.error').remove()
		username = $('#user-name').val()
		userpassword = $('#user-password').val()
		module = $('#module').val()

		if (username == "") {
			jQuery('#user-name').parent().after("<span class='error'>Please Enter Username! </span>")
			jQuery('#user-name').focus();
			error = 1;
		}
		if (userpassword == "") {
			jQuery('#user-password').parent().after("<span class='error'>Please Enter Password! </span>")
			jQuery('#user-password').focus();
			error = 1;
		}
		var response = grecaptcha.getResponse(logincaptchadiv);
		if (!response) {
			jQuery('#logincaptchadiv').append("<span class='error'>Please Check Captcha! </span>"); 
			error == 1;
		} 
		if (error == 0) {
			jQuery.ajax({
				url: globalvar.ajax_url,
				type: 'post',
				data: {
					action: 'customer_login',
					username: username,
					userpassword: userpassword,
					recaptcha: response,
					nonce: globalvar.nonce,
				},
				success: function(response) {
					response = jQuery.parseJSON(response)
					if (response == '1') {
						if (module == 'parking') {
							send_enquiry()
						} 
						else {
							location.href = globalvar.site_url + "/customer-dashboard"
						}
					}
					if (response == '2') {
						grecaptcha.reset();
						jQuery('.message').html("<span class='warning'>Username / Password Invalid!</span>")
						$('html, body').animate({scrollTop: $(".message").offset().top - 200}, 1000);
					}
					if (response == '3') {
						jQuery('.message').html("<span class='warning'>Invalid Recaptcha!</span>")
						$('html, body').animate({scrollTop: $(".message").offset().top - 200}, 1000);
						grecaptcha.reset();
					}
					if (response == '4') {
						jQuery('.message').html("<span class='warning'>Invalid Form Submission!</span>")
						$('html, body').animate({scrollTop: $(".message").offset().top - 200}, 1000);
						grecaptcha.reset();
					}
				}
			});
		}
	})	
	//QUICK PAY
	$("#quick-pay").click(function() {
		error = 0
		$('.error').remove()
		civil_id = $('#civil-id').val()
		account_no = $('#account_no').val()
		sub_no = $('#sub_no').val()
		module = $('#module').val()
		if (civil_id == "") {
			jQuery('#civil-id').parent().after("<span class='error'>Please Enter Civil ID! </span>")
			jQuery('#civil-id').focus();
			error = 1;
		}
		
		if(jQuery('.quick_payment_type:checked').val()=='Parking Payment'){
			if (sub_no == "") {
				jQuery('#sub_no').parent().after("<span class='error'>Please Enter Subscription No! </span>")
				jQuery('#sub_no').focus();
				error = 1;
			}
		}
		if(jQuery('.quick_payment_type:checked').val()=='Others'){
			if (account_no == "") {
				jQuery('#account_no').parent().after("<span class='error'>Please Enter Account No! </span>")
				jQuery('#account_no').focus();
				error = 1;
			}
		}
		var response = grecaptcha.getResponse(quickcaptchadiv);
		if (!response) {
			jQuery('#quickcaptchadiv').append("<span class='error'>Please Check Captcha! </span>"); 
			error == 1;
		}
		if (error == 0) {/* 
			jQuery.ajax({
				url: globalvar.ajax_url,
				type: 'post',
				data:{
					action: 'quick_pay',
					civil_id: civil_id,
					sub_no: sub_no,
					account_no: account_no,
					quick_payment_type: jQuery('.quick_payment_type:checked').val(),
					nonce: globalvar.nonce,
					recaptcha: response,
					},
				success: function(response) {
					response = jQuery.parseJSON(response)
					if (response == '1') {
					//jQuery('#frm-quick-pay').submit();
					}
					if (response == '2') {
						jQuery('.message').html("<span class='warning'>Civil ID / Account No / Contract No Invalid!</span>")
						$('html, body').animate({
						scrollTop: $(".message").offset().top - 200
						}, 1000);
					}
					if (response == '3') {
						jQuery('.message').html("<span class='warning'>Invalid Recaptcha!</span>")
						$('html, body').animate({
						scrollTop: $(".message").offset().top - 200
						}, 1000);
						grecaptcha.reset();
					}
						if (response == '4') {
						jQuery('.message').html("<span class='warning'>Invalid Form Submission!</span>")
						$('html, body').animate({scrollTop: $(".message").offset().top - 200}, 1000);
						grecaptcha.reset();
					}
				}
			}); */
		}
	})
	//****************************************************CUSTOMER JS ENDS******************************************************//
	//****************************************************PARKING ENQUIRY JS STARTS******************************************************//

	$(document).on('click', ".enquire-parking-now", function() { 
		$(".enquire-parking-now").removeClass('active')
		$(this).addClass('active')  
		parea = jQuery(this).attr('parea');
		governorate = jQuery(this).attr('governorate');
		featured_image = jQuery(this).attr('featured_image');
		plocation = jQuery(this).attr('location');
		jQuery('#parking_id').val($(this).attr('parking-id'))
		jQuery('#rooftop').val($(this).attr('rooftop'))
		jQuery('#parking_name').html($(this).attr('parking-title'))
		jQuery('#area-name').html(parea)
		jQuery('#governarate-name').html(governorate)
		jQuery('#featured-image').css('background', 'url(' + featured_image + ')')
		jQuery('#location').attr('src', plocation)
		$('.loading-property').removeClass('active')
		jQuery('.parking-floors-container').show();
		$('#parking-lot-list-container').hide();	
   })
   
	$("#send-enquiry").click(function() {
		$('.error').remove()
		customer_type = $('.customer_type:checked').val()
		numberofparkingspace = $('#numberofparkingspace').val()
		startdate = $('#startdate').val()
		parking_message = $('#parking-message').val()
		parking_id = $('#parking_id').val()
		customer_name = $('#customer-name').val()
		customer_email = $('#customer-email').val()
		customer_phone = $('#customer-phone').val()
		civil_id = $('#civil-id').val()
		rooftop = $('#rooftop').val()
		// todate = $('#c-todate').val()  
		message = $('#message').val()
		error = 0
		if (numberofparkingspace == "") {
			$('#numberofparkingspace').parent().after("<span class='error'>Please enter number of spaces required! </span>")
			$('#numberofparkingspace').focus();
			error = 1;
		} 
		if (startdate == "") {
			$('#startdate').parent().after("<span class='error'>Please select start date! </span>")
			$('#startdate').focus();
			error = 1;
		} 
		if (customer_name == "") {
			$('#customer-name').parent().after("<span class='error'>Please enter your name! </span>")
			$('#customer-name').focus();
			error = 1;
		} 
		if (customer_email == "") {
			$('#customer-email').parent().after("<span class='error'>Please enter your email! </span>")
			$('#customer-email').focus();
			error = 1;
		} 
		 if (!(isValidEmailAddress(customer_email)) && customer_email != "") {
            jQuery('#customer-email').parent().append("<span class='error'>Please Enter Valid E-mail! </span>")
            jQuery('#customer-email').focus();
            error = 1;
        }
		
		if (customer_phone == "") {
			$('#customer-phone').parent().after("<span class='error'>Please enter your phone! </span>")
			$('#customer-phone').focus();
			error = 1;
		} 
		if($('#agreeterms:checked').length==0){
		  $('#agreeterms').parent().after('<span class="error" style=" display: block;  width: 100%; text-align: CENTER; ">Please agree the terms and conditions</span>')

		error = 1
		}
		if (error == 0) {

	    jQuery(this).after('<div class="script-loader"><img src="'+globalvar.assets+'/images/loading.gif"></div>')
		jQuery(this).hide();
			jQuery.ajax({
			url: globalvar.ajax_url,
			type: 'post',
			data: {
				action: 'send_parking_lot_enquiry',
				numberofparkingspace: numberofparkingspace,
				startdate: startdate,
				parking_message: parking_message,
				customer_type: customer_type,
				customer_name: customer_name,
				customer_email: customer_email,
				customer_phone: customer_phone, 
				civil_id: civil_id, 
				rooftop: rooftop, 
				parking_id: parking_id, 

			},
			success: function(response) {
				response = jQuery.parseJSON(response)
			  location.href = globalvar.site_url + "/parking-lot-enquiry-sent-successfully/"

			}
			});
		}
    })
	//****************************************************PARKING ENQUIRY JS ENDS******************************************************//
	 
	
	
//CODE TO INDENT
	 var table =  $('#maintenance-list-table').DataTable({
	 
      'processing': true,
      'serverSide': true,
      'serverMethod': 'post',
      'ajax': {
          'url':globalvar.ajax_url+'?action=fetch_customer_maintenance_list',
		  
      }, 

dom: 'lr<"table-filter-container">tip',
       initComplete: function(settings){
          var api = new $.fn.dataTable.Api( settings );
          $('.table-filter-container', api.table().container()).append(
             $('#table-filter').detach().show()
          );
          
          $('#table-filter select').on('change', function(){
             table.search(this.value).draw();   
          });       
       },	  
	  pageLength : 5,
 
    lengthMenu: [[5, 10, 25, 100], [5, 10, 25, 100]],
      'columns': [
         { data: 'request_date' },
         { data: 'contract_no' },
         { data: 'maintenance_type' },
         { data: 'maintenance_title' },
         { data: 'maintenance_status' },
         { data: 'settings' }, 
      ],
	  "language": {
		"search": "Search Customer / Contract No:",
		    paginate: {
            previous: '‹',
            next:     '›'
        },
        aria: {
            paginate: {
                previous: '<',
                next:     '>'
            }
        }
	  },
	  aoColumnDefs: [
  {
     bSortable: false,
     aTargets: [ -1,-2,-3 ]
  }
]
   });
   
   if($('.quick_payment_type').length>0){
	   jQuery('#sub-payment').show()
			jQuery('#prop-payment').hide()	
   }
    $('.quick_payment_type').click(function() {
		
		if(jQuery(this).val()=="Parking Payment"){
		jQuery('#sub-payment').show()
			jQuery('#prop-payment').hide()	
		}
		if(jQuery(this).val()=="Others"){
				jQuery('#sub-payment').hide()
			jQuery('#prop-payment').show()
		}
	})
    $('#show-sign-up').click(function() {
        $('.signin-form').toggleClass('active')
        $('.signup-form').toggleClass('active')

    })
    $('#show-sign-in').click(function() {
        $('.signup-form').toggleClass('active')
        $('.signin-form').toggleClass('active')

    })
    $('.pay-rent-item').change(function() {
        totalamount = 0;
        jQuery('span.pay-amount').html('')

        jQuery('.pay-rent-item').each(function(index) {

            totalamount = totalamount + parseFloat(jQuery('option:selected', this).attr('amount'));

        });
        if (totalamount != 0) {
            jQuery('span.pay-amount').html('KD. ' + totalamount)
            jQuery('span.finalamt').html('KD. ' + totalamount)
        }
    })
    $('.pay-parking-rent').click(function() {
       $('.message').html('');
        count = 0
        contract = []
        cycle = []
        jQuery('.pay-rent-item').each(function(index) {
            if (jQuery('option:selected', this).attr('amount') != 0) {
                contract.push(jQuery(this).val())
                cycle.push((jQuery('option:selected', this).attr('cycle')))
                count++
            }

        });

        if (count == 0) {
            $('.message').html('<span class="error">Please select rents to pay !</span>')
            $('html, body').animate({
                scrollTop: $(".message").offset().top - 200
            }, 1000);
            return
        }
        jQuery('.property-block-container').hide()
        jQuery(this).hide()
        jQuery('.knet').show()
    })
    $('.pay-rent').click(function() {
       $('.message').html('');
     
        jQuery('.property-block-container').hide()
        jQuery('.card.payment').hide()
        jQuery('.knet').show()
    })
	
	
	
    $('.pay-parking-rent-knet').click(function() {
        count = 0
        contract = []
        cycle = []
		contract_no = $('#contract_no').val();
        jQuery('.pay-rent-item').each(function(index) {
            if (jQuery('option:selected', this).attr('amount') != 0) {
                contract.push(jQuery(this).val())
                cycle.push((jQuery('option:selected', this).attr('cycle')))
                count++
            }

        });

        if (count == 0) {
            $('.message').html('<span class="error">Please select rents to pay !</span>')
            $('html, body').animate({
                scrollTop: $(".message").offset().top - 200
            }, 1000);
        } else {
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'pay_parking_rent',
                    cycle: cycle,
                    contract: contract,
                    contract_no: contract_no,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)
                    if (response == '1') {

                        
                        location.href = globalvar.site_url + "/may-car-parking?msg=Parking Rent payed successfully!"
						 
                    }




                }
            });

        }
    })
	
	
	
    $('.pay-rent-knet').click(function() {
        count = 0
        contract = []
        cycle = []
		contract_no = $('#contract_no').val();
        jQuery('.pay-rent-item').each(function(index) {
            if (jQuery('option:selected', this).attr('amount') != 0) {
                contract.push(jQuery(this).val())
                cycle.push((jQuery('option:selected', this).attr('cycle')))
                count++
            }

        });

        if (count == 0) {
            $('.message').html('<span class="error">Please select rents to pay !</span>')
            $('html, body').animate({
                scrollTop: $(".message").offset().top - 200
            }, 1000);
        } else {
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'pay_rent',
                    cycle: cycle,
                    contract: contract,
                    contract_no: contract_no,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)
                    if (response == '1') {

                        if(contract_no==0){
                        location.href = globalvar.site_url + "/pay-rent?msg=Rent payed successfully!"
						}else{
							location.href = globalvar.site_url + "/quick-pay?contract_no="+contract_no+"&msg=Rent payed successfully!"
						}
                    }




                }
            });

        }
    })
    $(".payment-type").change(function() {
        payment_type = $(this).val();
        location.href = globalvar.site_url + "/payment-history/?payment_type=" + payment_type
    })
    $("#pay-for").change(function() {
        rent = $('#rent').val();
        noof = $(this).val();
        amount = parseFloat(rent) * parseFloat(noof);
        $("#amount-pay").html(amount)
        $("#payment").val(amount)
    })



    $(".user-type").click(function() {


        if (jQuery(this).val() == 'company') {

            jQuery('.company-name').show()
        } else {
            jQuery('.company-name').hide()

        }



    })
	jQuery("#request-maintenance").on('submit', function(e)
	{
        e.preventDefault(); 
        error = 0
        $('.error').remove()
        maintenance_title = $('#maintenance-title').val()
        maintenance_desc = $('#maintenance-desc').val()
        maintenance_type = $('#maintenance-type').val()
        parking_lot = $('#parking-lot').val()
        maintenance_image = $('#maintenance-image').val()  
  

        if (parking_lot == "") {
            jQuery('#parking-lot').parent().after("<span class='error'>Please Select Parking Lot! </span>")
            jQuery('#parking-lot').focus();
            error = 1;
        }
        if (maintenance_title == "") {
            jQuery('#maintenance-title').parent().after("<span class='error'>Please Enter Maintenance Title! </span>")
            jQuery('#maintenance-title').focus();
            error = 1;
        }
        if (maintenance_type == "") {
            jQuery('#maintenance-type').parent().after("<span class='error'>Please Select Maintenance Type! </span>")
            jQuery('#maintenance-type').focus();
            error = 1;
        }
         
		 if(maintenance_image !=''){
			var fileExtension = ['jpeg', 'jpg', 'pdf' ];
			 
			if ($.inArray(maintenance_image.split('.').pop().toLowerCase(), fileExtension) == -1) { 
					jQuery('#maintenance-image').parent().after("<span class='error'>Only formats are allowed : "+fileExtension.join(', ')+" </span>")
					jQuery('#maintenance-image').focus();
				}
		  }

        if (error == 0) {
			var ajax_url = globalvar.ajax_url;
			jQuery.ajax({
				url:ajax_url,
				type:"POST",
				processData: false,
				contentType: false,
				data:  new FormData(this),
				success : function( response ){
					var returnedData = JSON.parse(response);
					 $('#table-filter select').change();
					 jQuery('.message').html("<span class='success'>Maintenance Request Sent Successfully!</span>")
					 $('#maintenance-request').modal('toggle');
				},
			});
			return false;
			
			
			//////////////////
          

        }

    })
    $("#register-customer").click(function() {
        error = 0
        $('.error').remove()
        c_name = $('#c-name').val()
        c_civilid = $('#c-civilid').val()
        c_phone = $('#c-phone').val()
        c_email = $('#c-email').val()
        user_type = jQuery('.user-type:checked').val()
        co_name = $('#co-name').val()
        username = $('#c-username').val()
        upassword = $('#c-password').val()
        rupassword = $('#re-c-password').val()
        module = $('#module').val()

        if (c_name == "") {
            jQuery('#c-name').parent().after("<span class='error'>Please Enter Customer Name! </span>")
            jQuery('#c-name').focus();
            error = 1;
        }
        if (c_civilid == "") {
            jQuery('#c-civilid').parent().after("<span class='error'>Please Enter Civil ID Name! </span>")
            jQuery('#c-civilid').focus();
            error = 1;
        }
        if (c_phone == "") {
            jQuery('#c-phone').parent().after("<span class='error'>Please Enter Phone No! </span>")
            jQuery('#c-phone').focus();
            error = 1;
        }
        if (c_email == "") {
            jQuery('#c-email').parent().after("<span class='error'>Please Enter Email! </span>")
            jQuery('#c-email').focus();
            error = 1;
        }
        if (!(isValidEmailAddress(c_email)) && c_email != "") {
            jQuery('#c-email').parent().append("<span class='error'>Please Enter Valid E-mail! </span>")
            jQuery('#c-email').focus();
            error = 1;
        }
        if (user_type == "company" && co_name == '') {
            jQuery('#co-name').parent().after("<span class='error'>Please Enter Company Name! </span>")
            jQuery('#co-name').focus();
            error = 1;
        }

        if (username == "") {
            $('#c-username').parent().after("<span class='error'>Please Enter Username! </span>")
            $('#c-username').focus();
            error = 1;
        }
        if (upassword == "") {
            $('#c-password').parent().after("<span class='error'>Please Enter Password! </span>")
            $('#c-password').focus();
            error = 1;
        }
        if (rupassword == "") {
            $('#re-c-password').parent().after("<span class='error'>Please Re-Enter Password! </span>")
            $('#re-c-password').focus();
            error = 1;
        }
        if (upassword != rupassword && rupassword != "" && upassword != "") {
            $('#re-c-password').parent().after("<span class='error'>Passwords do not match! </span>")
            $('#re-c-password').focus();
            error = 1;
        }


        if (error == 0) {
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'register_customer',
                    username: username,
                    upassword: upassword,
                    user_type: user_type,
                    c_name: c_name,
                    c_phone: c_phone,
                    c_civilid: c_civilid,
                    c_name: c_name,
                    co_name: co_name,
                    c_email: c_email,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)
                    if (response == '1') {




                        if (module == 'parking') {
                            send_enquiry()
                        } else {
                            location.href = globalvar.site_url + "/customer-dashboard"
                        }
                    }
                    if (response == '2') {


                        jQuery('.message').html("<span class='warning'>Username Already Exist , Please Try Another!</span>")
                        $('html, body').animate({
                            scrollTop: $(".message").offset().top - 200
                        }, 1000);
                    }
                    if (response == '3') {


                        jQuery('.message').html("<span class='warning'>Email Already Exist , Please Try Another!</span>")
                        $('html, body').animate({
                            scrollTop: $(".message").offset().top - 200
                        }, 1000);
                    }




                }
            });

        }

    })

   
    $(".pay-bill").click(function() {


        if (jQuery('.utility_item:checked').length == 0) {
            jQuery('.message').append('<span class="error">Please Select Bills To Pay!</span>')
            $('html, body').animate({
                scrollTop: $(".message").offset().top
            }, 100);
            return
        }
        amount = 0;
        jQuery('.utility_item:checked').each(function(index) {
            amount = amount + parseFloat($(this).attr('amount'));

        });
        jQuery('.finalamt').html(amount)
        jQuery('.property-block-container').hide()
        jQuery(this).hide()
        jQuery('.knet').show()

    })
    $(".pay-bill-knet").click(function() {
        jQuery('.error').remove()

        if (jQuery('.utility_item:checked').length == 0) {
            jQuery('.message').append('<span class="error">Please Select Bills To Pay!</span>')
            $('html, body').animate({
                scrollTop: $(".message").offset().top
            }, 100);
            return
        }
        bills = [];
        jQuery('.utility_item:checked').each(function(index) {
            console.log(index + ": " + $(this).val());
            bills.push($(this).val())
        });

        jQuery.ajax({
            url: globalvar.ajax_url,
            type: 'post',
            data: {
                action: 'bill_payment',
                bills: bills,

            },
            success: function(response) {
                response = jQuery.parseJSON(response)
                if (response == '1') {


                    location.href = globalvar.site_url + "/pay-water-electricity-bill/?msg=Bill Payment Done Successfully!"
                }




            }
        });

    })
    $("#btn-change-password").click(function() {
        error = 0
        $('.error').remove()
        $('.message').remove()
        old_password = $('#old-password').val()
        new_password = $('#new-password').val()
        renew_password = $('#re-new-password').val()

        if (old_password == "") {
            jQuery('#old-password').parent().after("<span class='error'>Please enter old password! </span>")
            jQuery('#old-password').focus();
            error = 1;
        }
        if (new_password == "") {
            jQuery('#new-password').parent().after("<span class='error'>Please enter new password! </span>")
            jQuery('#new-password').focus();
            error = 1;
        }

        if (renew_password == "") {
            jQuery('#re-new-password').parent().after("<span class='error'>Please re-enter new password! </span>")
            jQuery('#re-new-password').focus();
            error = 1;
        }
        if (renew_password != new_password && renew_password != "" && new_password != "") {
            jQuery('#re-new-password').parent().after("<span class='error'>New passwords do not match ! </span>")
            jQuery('#re-new-password').focus();
            error = 1;
        }

        if (error == 0) {
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'customer_change_password',
                    old_password: old_password,
                    new_password: new_password,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)

                    if (response == '1') {


                        jQuery(".modal-body").html("<div class='message'>Password Changed Successfully!</div>")
                    }
                    if (response == '2') {


                        jQuery(".modal-body").append("<div class='message'><span class='error'>Old Password In-correct!</span></div>")
                    }




                }
            });

        }

    })
    $("#make-payment").click(function() {
        error = 0
        $('.error').remove()
        contract_no = $('#contract-no').val()
        civil_id = $('#civil-id').val()
        email = $('#email-address').val()
        payment = $('#payment').val()
        noof = $("#pay-for").val()
        id = $('#id').val()

        if (contract_no == "") {
            jQuery('#contract-no').parent().after("<span class='error'>Please Contract No! </span>")
            jQuery('#contract-no').focus();
            error = 1;
        }
        if (civil_id == "") {
            jQuery('#civil-id').parent().append("<span class='error'>Please Enter Civil ID No! </span>")
            jQuery('#civil-id').focus();
            error = 1;
        }

        if (email == "") {
            jQuery('#email-address').parent().append("<span class='error'>Please Enter E-mail! </span>")
            jQuery('#email-address').focus();
            error = 1;
        }
        if (!(isValidEmailAddress(email)) && email != "") {
            jQuery('#email-address').parent().append("<span class='error'>Please Enter Valid E-mail! </span>")
            jQuery('#email-address').focus();
            error = 1;
        }
        if (error == 0) {
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'make_payment',
                    civil_id: civil_id,
                    contract_no: contract_no,
                    payment: payment,
                    email: email,
                    noof: noof,
                    id: id,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)
                    if (response == '1') {


                        location.href = globalvar.site_url + "/my-properties/?msg=Rent Payment Done Successfully!"
                    }




                }
            });

        }

    })
	
	
	//serach locations
	
	
    $(".search_location").click(function() {
        propertyoffset = 0
        filtered = 1 
        governorate = $('#governorate').val()
        location_area = $('#area').val()  
        $('.loading-property').addClass('active')
        jQuery.ajax({
            url: globalvar.ajax_url,
            type: 'post',
            data: {
                action: 'search_location',
                
                governorate: governorate,
                location_area: location_area, 
                offset: 0,

            },
            success: function(response) {
                response = jQuery.parseJSON(response)
                $('.loading-property').removeClass('active')
                $('.property-list').html(response.html)
                $('.load-more-locations').removeClass('show-1')
                $('.load-more-locations').removeClass('show-0')
                $('.load-more-locations').addClass('show-' + response.paging)
                $('html, body').animate({
                    scrollTop: $(".property-list").offset().top
                }, 600);
                if (jQuery('ul.property-list li').length == 0) {
                    $('.property-list').html('<h2>No Locations Found!</h2>')
                }


            }
        });
    })
	
	
    ///search parking


    $(".search_parking_lots").click(function() {
        propertyoffset = 0
        filtered = 1
        governorate = $('#governorate').val()
        suscription_rooftop = $('#suscription_rooftop').val()
        subscription_type = $('#subscription_type').val()
        subscription_id = $('#subscription_id').val()
        location_area = $('#area').val()

        $('.loading-property').addClass('active')
        jQuery.ajax({
            url: globalvar.ajax_url,
            type: 'post',
            data: {
                action: 'search_parking_lot',
                rooftop: suscription_rooftop,
                subscription_type: subscription_type,
                subscription_id: subscription_id,
                governorate: governorate,
                location_area: location_area,
                offset: 0,

            },
            success: function(response) {
                response = jQuery.parseJSON(response)
				$('#parking-lot-list-container').show()
				$('.parking-floors-container').hide()
				$('.enquiry-form').hide()
				$('#signin').hide()
                $('.loading-property').removeClass('active')
                $('.property-list').html(response.html)
                $('.load-more-properties').removeClass('show-1')
                $('.load-more-properties').removeClass('show-0')
                $('.load-more-properties').addClass('show-' + response.paging)
                $('html, body').animate({
                    scrollTop: $(".property-list").offset().top
                }, 600);
                if (jQuery('ul.property-list li').length == 0) {
                    $('.property-list').html('<h2>No Properties Found!</h2>')
                }


            }
        });
    })



    $(".search_parking").click(function() {
        propertyoffset = 0
        filtered = 1 
        governorate = $('#governorate').val()
        location_area = $('#area').val() 
        parking_type = $('#parking_type').val()  
        property_size_min = $('#area-filter-min').val()
        property_size_max = $('#area-filter-max').val()
        $('.loading-property').addClass('active')
        jQuery.ajax({
            url: globalvar.ajax_url,
            type: 'post',
            data: {
                action: 'search_parking',
                
                governorate: governorate,
                location_area: location_area,
                parking_type: parking_type,  
                property_size_max: property_size_max,
                property_size_min: property_size_min,
                offset: 0,

            },
            success: function(response) {
                response = jQuery.parseJSON(response)
                $('.loading-property').removeClass('active')
                $('.property-list').html(response.html)
                $('.load-more-properties').removeClass('show-1')
                $('.load-more-properties').removeClass('show-0')
                $('.load-more-properties').addClass('show-' + response.paging)
                $('html, body').animate({
                    scrollTop: $(".property-list").offset().top
                }, 600);
                if (jQuery('ul.property-list li').length == 0) {
                    $('.property-list').html('<h2>No Parking Found!</h2>')
                }


            }
        });
    })
    $(".search_property").click(function() {
        propertyoffset = 0
        filtered = 1
        property_id = $('#property_id').val()
        governorate = $('#governorate').val()
        location_area = $('#area').val()
        block_no = $('#block_no').val()
        property_type = $('#property_type').val()
        bedroom_min = $('#bedroom-filter-min').val()
        bedroom_max = $('#bedroom-filter-max').val()
        bathroom_min = $('#bathroom-filter-min').val()
        bathroom_max = $('#bathroom-filter-max').val()
        price_min = $('#price-filter-min').val()
        price_max = $('#price-filter-max').val()
        property_size_min = $('#area-filter-min').val()
        property_size_max = $('#area-filter-max').val()
        $('.loading-property').addClass('active')
        jQuery.ajax({
            url: globalvar.ajax_url,
            type: 'post',
            data: {
                action: 'search_property',
                property_id: property_id,
                block_no: block_no,
                governorate: governorate,
                location_area: location_area,
                property_type: property_type,
                bedroom_min: bedroom_min,
                bedroom_max: bedroom_max,
                bathroom_min: bathroom_min,
                bathroom_max: bathroom_max,
                price_max: price_max,
                price_min: price_min,
                property_size_max: property_size_max,
                property_size_min: property_size_min,
                offset: 0,

            },
            success: function(response) {
                response = jQuery.parseJSON(response)
                $('.loading-property').removeClass('active')
                $('.property-list').html(response.html)
                $('.load-more-properties').removeClass('show-1')
                $('.load-more-properties').removeClass('show-0')
                $('.load-more-properties').addClass('show-' + response.paging)
                $('html, body').animate({
                    scrollTop: $(".property-list").offset().top
                }, 600);
                if (jQuery('ul.property-list li').length == 0) {
                    $('.property-list').html('<h2>No Parking Locations Found!</h2>')
                }


            }
        });
    })
    $(".load-more-locations").click(function() {
		console.log(propertyoffset)
        propertyoffset = propertyoffset + 6
        $('.loading-property').addClass('active')
console.log(propertyoffset)
        if (filtered == 0) {
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'load_more_locations',
                    offset: propertyoffset,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)
                    $('.loading-property').removeClass('active')
                    $('.property-list').append(response.html)
                    $('.load-more-locations').removeClass('show-1')
                    $('.load-more-locations').removeClass('show-0')
                    $('.load-more-locations').addClass('show-' + response.paging)




                }
            });
        }
        if (filtered == 1) { 
            governorate = $('#governorate').val()
            location_area = $('#area').val()
           
            $('.loading-property').addClass('active')
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'search_location', 
                    governorate: governorate,
                    location_area: location_area,
                    
                    offset: propertyoffset,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)
                    $('.loading-property').removeClass('active')
                    $('.property-list').append(response.html)
                    $('.load-more-locations').removeClass('show-1')
                    $('.load-more-locations').removeClass('show-0')
                    $('.load-more-locations').addClass('show-' + response.paging)
                    $('html, body').animate({
                        scrollTop: $(".property-list").offset().top
                    }, 600);
                    if (jQuery('ul.property-list li').length == 0) {
                        $('.property-list').html('<h2>No Properties Found!</h2>')
                    }


                }
            });
        }
    })
    $(".load-more-properties").click(function() {
        propertyoffset = propertyoffset + 6
        $('.loading-property').addClass('active')

        if (filtered == 0) {
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'load_more_property',
                    offset: propertyoffset,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)
                    $('.loading-property').removeClass('active')
                    $('.property-list').append(response.html)
                    $('.load-more-properties').removeClass('show-1')
                    $('.load-more-properties').removeClass('show-0')
                    $('.load-more-properties').addClass('show-' + response.paging)




                }
            });
        }
        if (filtered == 1) {
            property_id = $('#property_id').val()
            governorate = $('#governorate').val()
            location_area = $('#area').val()
            block_no = $('#block_no').val()
            property_type = $('#property_type').val()
            bedroom_min = $('#bedroom-filter-min').val()
            bedroom_max = $('#bedroom-filter-max').val()
            bathroom_min = $('#bathroom-filter-min').val()
            bathroom_max = $('#bathroom-filter-max').val()
            price_min = $('#price-filter-min').val()
            price_max = $('#price-filter-max').val()
            property_size_min = $('#area-filter-min').val()
            property_size_max = $('#area-filter-max').val()
            $('.loading-property').addClass('active')
            jQuery.ajax({
                url: globalvar.ajax_url,
                type: 'post',
                data: {
                    action: 'search_property',
                    property_id: property_id,
                    block_no: block_no,
                    governorate: governorate,
                    location_area: location_area,
                    property_type: property_type,
                    bedroom_min: bedroom_min,
                    bedroom_max: bedroom_max,
                    bathroom_min: bathroom_min,
                    bathroom_max: bathroom_max,
                    price_max: price_max,
                    price_min: price_min,
                    property_size_max: property_size_max,
                    property_size_min: property_size_min,
                    offset: propertyoffset,

                },
                success: function(response) {
                    response = jQuery.parseJSON(response)
                    $('.loading-property').removeClass('active')
                    $('.property-list').append(response.html)
                    $('.load-more-properties').removeClass('show-1')
                    $('.load-more-properties').removeClass('show-0')
                    $('.load-more-properties').addClass('show-' + response.paging)
                    $('html, body').animate({
                        scrollTop: $(".property-list").offset().top
                    }, 600);
                    if (jQuery('ul.property-list li').length == 0) {
                        $('.property-list').html('<h2>No Properties Found!</h2>')
                    }


                }
            });
        }
    })


    /*
    FETCH PARKING LOTS
    */


    $("#go-to-enquiry").click(function() {


        error = 0
        jQuery('.error').remove()
         
if(jQuery('#subscription_type').val()!='Individual'  ||  jQuery('#suscription_rooftop').val()!='Yes' ){
            parking = ptitle =  $('option:selected', $('.parking-floor-selected')).attr('floorid');;
            console.log('parking' + parking)
            req_parking = $('#req-parking-' + parking).val()
            if (req_parking == '' || req_parking == 0) {
                $('#req-parking-' + parking).after('<span class="error">Enter required capacity</>')
                error = 1
            }

}  

 
        if (error == 0) {
            jQuery('.parking-floors-container').hide()
			if(jQuery('#subscription_type').val()=='Individual'){
				jQuery('.capacity-block').addClass('active')
			}
			if(jQuery('#suscription_rooftop').val()=='Yes'){
				jQuery('.event-details-block').addClass('active')
				jQuery('.eventdate').addClass('active')
				jQuery('.normaldate').removeClass('active')
			}else{
				
				jQuery('.normaldate').addClass('active')
				jQuery('.eventdate').removeClass('active')
			}
            jQuery('.enquiry-form').show()
            jQuery('input#user-name').val('')
            jQuery('input#user-password').val('')
            html = ''
            html += '<div class="cart-parking">'+jQuery('#parking_lot_trans').val()+': <span>' + jQuery("#parking_name").val() + '</span></div>'
           // html += '<div class="spayment">Subscription Payment: <span>' + jQuery(".subscription_payment").val() + '</span></div>'
            html += '<div class="sfloors">Selected Parking Space: '
            
                pid = $('.parking-floor-selected').val()
                ptitle =  $('option:selected', $('.parking-floor-selected')).attr('title');

           
                    html += ' <span>' + ptitle + ':  Capacity required - ' + jQuery("#req-parking-" + pid).val() + ' Amount - KD ' + jQuery("#dparking-amount-" + pid).val() + ' </span>'
               
            

            html += '</div>'

            html += '<div class="stotalpayment">Total Payment: <span> KD ' + jQuery("#dtotal-parking-payable").val() + '</span></div>'
            $('.cart-info').html(html)

        }
    })

    $(".rooftop").click(function() {
        rooftop = '';
        governorate = '';
        parea = '';
        if ($(".rooftop:checked").length > 0) {
            rooftop = 'Yes'
        }
        if (jQuery("#governorate").val() != '') {
            governorate = jQuery("#governorate").val();
        }
        if (jQuery('#area').val() != '') {
            parea = jQuery('#area').val()
        }
        jQuery.ajax({
            url: globalvar.ajax_url,
            type: 'post',
            data: {
                action: 'fetch_all_parking_lots',
                parea: parea,
                governorate: governorate,
                rooftop: rooftop,

            },
            success: function(response) {
                response = jQuery.parseJSON(response)
                $('#parkinglots').html(response.html)
                jQuery('#parkinglots').trigger('change')




            }
        });

    })
    $("#area").change(function() {
        governorate = '';
        parea = '';
        rooftop = '';
        if ($(".rooftop:checked").length > 0) {
            rooftop = 'Yes'
        }
        if (jQuery(this).val() != '') {
            parea = jQuery(this).val()
        }
        if (jQuery("#governorate").val() != '') {
            governorate = jQuery("#governorate").val();
        }
        jQuery.ajax({
            url: globalvar.ajax_url,
            type: 'post',
            data: {
                action: 'fetch_all_parking_lots',
                parea: parea,
                governorate: governorate,
                rooftop: rooftop,

            },
            success: function(response) {
                response = jQuery.parseJSON(response)
                $('#parkinglots').html(response.html)




            }
        });


    })
    $("#governorate").change(function() {
        governorate = '';
        parea = '';
        rooftop = '';
        ftype = $(this).attr('ftype')
        if ($(".rooftop:checked").length > 0) {
            rooftop = 'Yes'
        }

        if (jQuery(this).val() != '') {
            governorate = jQuery(this).val();
        }
        jQuery.ajax({
            url: globalvar.ajax_url,
            type: 'post',
            data: {
                action: 'fetch_all_area_item',
                governorate: governorate,
                rooftop: rooftop,
                ftype: ftype,

            },
            success: function(response) {
                response = jQuery.parseJSON(response)

                $('#parkinglots').html(response.html)
                $('#area').empty()

                $('#area').html(response.parea)




            }
        });


    })
	
	
	 
	
	 

   

    $(document).on('keyup', '.req-parking', function() {
        max = jQuery(this).attr('max')
        charLimit(this, max);
    });
    /*parking calculations*/

    $(document).on('change', '.subscription_payment', function() {
        calculate_parking()
    })
    $(document).on('click', '.parking-floor-selected', function() {
        pid = jQuery(this).val()
        if (jQuery(this).prop('checked') == true) {
            if (jQuery(this).attr('rooftop') == 'Yes') {
                jQuery("#req-parking-" + pid).val(1)
            }
        } else {
            console.log("#req-parking-" + pid)
            jQuery("#req-parking-" + pid).val('')
        }
        calculate_parking()
    })
    $(document).on('keyup', '.calculate-parking', function() {
        calculate_parking()
    })

});

//parking calculation function

function calculate_parking() {
    subscription_payment = '';
    totalpayment = 0
    jQuery('.error').remove()
 
    console.log(subscription_payment)

    unitrate = 0

    if (subscription_payment == 'Daily') {
        unitrate = $(".enquire-parking-now.active").attr('daily')
    }
    if (subscription_payment == 'Weekly') {

        unitrate = $(".enquire-parking-now.active").attr('weekly')
    }
    if (subscription_payment == 'Monthly') {

        unitrate = $(".enquire-parking-now.active").attr('monthly')
    }
    if (subscription_payment == 'Annually') {

        unitrate = $(".enquire-parking-now.active").attr('annual')
    }
    if (unitrate == '') {
        unitrate = 0
    }
    console.log(unitrate)
    console.log(subscription_payment)

     pid = $('option:selected', $('.parking-floor-selected')).attr('floorid');
        

        if (jQuery("#req-parking-" + pid).val() != "" && jQuery("#req-parking-" + pid).val() != 0) {
            jQuery(this).prop("checked", true)
            if (jQuery(this).attr('rooftop') == 'Yes') {
                unitrate = jQuery('#parkinglots').children(":selected").attr('rooftop')

            }
            $(this).parent().addClass('active')
            req_parking = parseInt(jQuery("#req-parking-" + pid).val())

            parkingamount = req_parking * parseInt(unitrate)
            totalpayment = totalpayment + (parkingamount)
            jQuery('#parking-amount-' + pid).find('span').html(parkingamount)
            jQuery('#dparking-amount-' + pid).val(parkingamount)
        } else {
            console.log('#parking-amount-' + pid)
            jQuery('#parking-amount-' + pid).find('span').html(0)
        }


     
    jQuery('#total-parking-payable').find('span').html(totalpayment)
    jQuery('#dtotal-parking-payable').val(totalpayment)
}

 