
//****************************************************COMMON JS STARTS******************************************************//

jQuery('select#property-contract').select2()
//****************************************************COMMON JS ENDS******************************************************//
//PHONE VALIDATION EMAIL
	function isValidEmailAddress(emailAddress) {
	var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
	return pattern.test(emailAddress);
	}; 

//PHONE VALIDATION FUNCTION
function isValidPhone(phoneNumber) {
        if (($.trim(phoneNumber).length != 8 || isNaN(phoneNumber)) && $.trim(phoneNumber) !='') {
			 return false;
		 }
		  return true;
};
	
	
jQuery(".add-complaint").on('click', function(e)
	{
		error = 0
		jQuery('.error').remove()
		  e.preventDefault(); 
		 
		  if(jQuery('.description').val()==''){
			  error = 1
			  jQuery('.description').parent().append("<span class='error'>Please enter you complaint</span>");
		  }
	 
		     
		  if(error==0){
			  jQuery('#add-comp').val(1);
			  jQuery('#frmcomplaint').submit()
		  }
	})	
	
	
jQuery(".user-notifications").click(function(){
 console.log('clicked')

  jQuery.ajax({
                 url: gajax,
                 type: 'post',
                 data: {
                     action: 'notifications_read', 
					 
                      
                 },
                 success: function(response) {  
                        jQuery('.user-notifications span.notification').hide();
                 }
             });
})

	jQuery("#request-maintenance").on('submit', function(e)
	{
        e.preventDefault(); 
        error = 0
        $('.error').remove()
        maintenance_title = $('#maintenance-title').val()
        maintenance_for = $('#maintenance-for').val()
        maintenance_desc = $('#maintenance-desc').val()
        maintenance_type = $('#maintenance-type').val()
        maintenance_image = $('#maintenance-image').val()  
  

        if (maintenance_for == "") {
            jQuery('#maintenance-for').parent().after("<span class='error'>Please Select Property! </span>")
            jQuery('#maintenance-for').focus();
            error = 1;
        }
        if (maintenance_title == "") {
            jQuery('#maintenance-title').parent().after("<span class='error'>Please Enter Maintenance Title! </span>")
            jQuery('#maintenance-title').focus();
            error = 1;
        }
        if (maintenance_type == "") {
            jQuery('#maintenance-type').parent().after("<span class='error'>Please Select Maintenance Type! </span>")
            jQuery('#maintenance-type').focus();
            error = 1;
        }
         
		 if(maintenance_image !=''){
			var fileExtension = ['jpeg', 'jpg', 'pdf' ];
			 
			if ($.inArray(maintenance_image.split('.').pop().toLowerCase(), fileExtension) == -1) { 
					jQuery('#maintenance-image').parent().after("<span class='error'>Only formats are allowed : "+fileExtension.join(', ')+" </span>")
					jQuery('#maintenance-image').focus();
				}
		  }

        if (error == 0) {
			var ajax_url = globalvar.ajax_url;
			jQuery.ajax({
				url:ajax_url,
				type:"POST",
				processData: false,
				contentType: false,
				data:  new FormData(this),
				success : function( response ){
					var returnedData = JSON.parse(response);
					 $('#table-filter select').change();
					 jQuery('.message').html("<span class='success'>Maintenance Request Sent Successfully!</span>")
					 $('#maintenance-request').modal('toggle');
				},
			});
			return false;
			
			
			//////////////////
          

        }

    })